`timescale 1ns / 1ps

module registers(
    input clock,
    input [25:21] rd_reg_1,
    input [20:16] rd_reg_2,
    input [15:11] wr_reg,
    output reg [31:0] rd_data_1,
    output reg [31:0] rd_data_2,
    input [31:0] wr_data,
    input wr_en
    );
    reg [31:0] reg_cont [31:0];
    integer i;
    initial for (i = 0; i < 32; i = i + 1) reg_cont[i] <= 0;
    
    always @ (rd_reg_1 or rd_reg_2) begin
        rd_data_1 = reg_cont[rd_reg_1];
        rd_data_2 = reg_cont[rd_reg_2];
    end
    
    always @ (negedge clock) 
        if (wr_en) reg_cont[wr_reg] <= wr_data;
endmodule
