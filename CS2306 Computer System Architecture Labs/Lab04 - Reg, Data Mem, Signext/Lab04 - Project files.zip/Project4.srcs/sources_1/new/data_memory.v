`timescale 1ns / 1ps

module data_memory(
    input clock,
    input [31:0] addr,
    input mem_wr,
    input [31:0] wr_data,
    input mem_rd,
    output [31:0] rd_data
    );
    
    reg [31:0] mem_cont [63:0];
    integer i;
    initial for(i = 0; i < 64; i = i + 1) mem_cont[i] <= 0;
    assign rd_data = mem_rd && !mem_wr ? mem_cont[addr] : 0;
    always @ (negedge clock) if (mem_wr) mem_cont[addr] = wr_data;
endmodule
