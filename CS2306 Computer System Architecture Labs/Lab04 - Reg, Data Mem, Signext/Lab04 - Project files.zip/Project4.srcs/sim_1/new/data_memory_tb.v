`timescale 1ns / 1ps

module data_memory_tb(
    
    );
    
    reg Clock;
    reg [31:0] Address;
    reg MemoryWrite;
    reg [31:0] WriteData;
    reg MemoryRead;
    wire [31:0] ReadData;
    
    data_memory example_datamem(
        .clock(Clock),
        .addr(Address),
        .mem_wr(MemoryWrite),
        .wr_data(WriteData),
        .mem_rd(MemoryRead),
        .rd_data(ReadData)
        );
        
    always #(100) Clock = !Clock;
    
    initial begin
        Clock = 0;
        Address = 0;
        WriteData = 0;
        MemoryWrite = 0;
        MemoryRead = 0;

        #185; //Time 185
        MemoryWrite = 1;
        Address = 32'b000111;
        WriteData = 32'he0000000;

        #100; //Time 285
        MemoryWrite = 1;
        WriteData = 32'hffffffff;
        Address = 32'b000110;

        #185; //Time 470
        Address = 7;
        MemoryRead = 1;
        MemoryWrite = 0;

        #80; //Time 550
        MemoryWrite = 1;
        Address = 8;
        WriteData = 32'haaaaaaaa;
        
        #80; //Time 630
        Address = 6;
        MemoryWrite = 0;
        MemoryRead = 1;
    end
endmodule
