`timescale 1ns / 1ps

module registers_tb(

    );
    reg Clock;
    reg [4:0] ReadReg1;
    reg [4:0] ReadReg2;
    reg [4:0] WriteReg;
    wire [31:0] ReadData1;
    wire [31:0] ReadData2;
    reg [31:0] WriteData;
    reg WriteEnable;
    
    registers example_reg(
        .clock(Clock),
        .rd_reg_1(ReadReg1),
        .rd_reg_2(ReadReg2),
        .wr_reg(WriteReg),
        .rd_data_1(ReadData1),
        .rd_data_2(ReadData2),
        .wr_data(WriteData),
        .wr_en(WriteEnable)
        );
    
    always #(100) Clock = !Clock;
    // negedge at 100, 300, 500, 700, etc.
    
    initial begin
        Clock = 1;
        ReadReg1 = 0;
        ReadReg2 = 0;
        WriteReg = 0;
        WriteData = 0;
        WriteEnable = 0;
        
        #250; //Time 250
        WriteEnable = 1;
        WriteReg = 21;
        WriteData = 32'hffff0000;
        //At 300 Write Operation taken
        
        #200; //Time 450
        WriteReg = 10;
        WriteData = 32'h0000ffff;
        //At 500 Write Operation taken
        
        #200; //Time 650
        WriteEnable = 0;
        WriteReg = 0;
        WriteData = 32'hffffffff;
        //Write Operation will be banned
        
        #75; //Time 725
        ReadReg1 = 21;
        ReadReg2 = 10;
        //Read data written by operation at 300 & 500
        
        #75; //Time 800
        ReadReg1 = 0;
        ReadReg2 = 0;
        //Confirm that operation at 700 is banned
    end
endmodule
