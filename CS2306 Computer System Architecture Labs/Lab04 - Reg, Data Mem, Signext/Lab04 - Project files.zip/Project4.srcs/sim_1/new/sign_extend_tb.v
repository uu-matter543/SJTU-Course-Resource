`timescale 1ns / 1ps

module sign_extend_tb(
    
    );
    
    reg [15:0] Data16;
    wire [31:0] Data32;
    
    sign_extend example_signext(
        .data_16(Data16),
        .data_32(Data32)
    );
    
    initial begin
        Data16 = 0;
        #100; Data16 = 16'h0001;
        #100; Data16 = 16'hffff;
        #100; Data16 = 16'h7fff;
        #100; Data16 = 16'h8000;
    end
endmodule
