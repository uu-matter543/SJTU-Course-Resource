`timescale 1ns / 1ps

module pc_control_unit(
    input [31:0] old_pc,
    input [31:0] jr_reg,
    input jump,
    input jump_reg,
    input branch,
    input zero,
    input reset,
    input [25:0] j_targ,
    input [31:0] beq_offset,
    output [31:0] new_pc
    );
    
    wire [31:0] pc_add_4;
    assign pc_add_4 = old_pc + 4;
    assign new_pc = jump_reg ? jr_reg :
                       (jump ? {pc_add_4[31:28], j_targ<<2} :
             (branch && zero ? (beq_offset<<2) + pc_add_4 : 
                               pc_add_4));
endmodule
