`timescale 1ns / 1ps

module instr_16_tb(
    
    );
    reg sys_clk;
    reg reset;
    
    Top CPU(
        .Clk(sys_clk),
        .Reset(reset)
    );
    
    always #(100) sys_clk = !sys_clk;
    initial begin
        sys_clk = 0;
        reset = 0;
        $readmemh ("lab05dat_tb", CPU.DataMem.mem_cont);
        $readmemb ("lab05instr_tb", CPU.InstrMem.mem_cont);
        #100; reset = 1;
        #100; reset = 0;
        
    end
endmodule
