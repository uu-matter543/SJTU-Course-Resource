`timescale 1ns / 1ps

module instruction_memory(
    input reset,
    input [31:0] addr,
    output [31:0] instr
    );
    reg [31:0] mem_cont [63:0];
    assign instr = reset ? mem_cont[0] : mem_cont[addr>>2];
    
endmodule
