`timescale 1ns / 1ps

module data_memory(
    input clock,
    input [31:0] addr,
    input mem_wr,
    input [31:0] wr_data,
    input mem_rd,
    output [31:0] rd_data
    );
    
    reg [31:0] mem_cont [63:0];
    assign rd_data = mem_rd && !mem_wr ? mem_cont[addr>>2] : 0;
    always @ (negedge clock) if (mem_wr) mem_cont[addr>>2] = wr_data;
endmodule
