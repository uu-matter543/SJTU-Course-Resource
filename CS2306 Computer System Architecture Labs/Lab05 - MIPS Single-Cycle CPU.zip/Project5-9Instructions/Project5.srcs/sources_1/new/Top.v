`timescale 1ns / 1ps

module Top(
    input Reset,
    input Clk
    );
    wire [31:0] Instruction;
    
    wire RegDst;
    wire Jump;
    wire Branch;
    wire MemRead;
    wire MemWrite;
    wire [1:0] ALU_Op;
    wire MemToReg;
    wire ALUSrc;
    wire RegWriteEn;
    control_unit Ctr(
        .op_code(Instruction[31:26]),
        .reg_dst(RegDst),
        .alu_src(ALUSrc),
        .mem_to_reg(MemToReg),
        .reg_write(RegWriteEn),
        .mem_read(MemRead),
        .mem_write(MemWrite),
        .branch(Branch),
        .alu_op(ALU_Op),
        .jump(Jump)
    );
    
    wire [3:0] ALUCtrOut;
    alu_control_unit ALU_Ctr(
        .funct(Instruction[5:0]),
        .alu_op(ALU_Op),
        .alu_ctr_out(ALUCtrOut)
    );
    
    wire [31:0] RegData1;
    wire [31:0] RegData2;
    wire [31:0] WriteData;
    wire [4:0] WriteReg;
    assign WriteReg = RegDst ?
           Instruction[15:11] :
           Instruction[20:16];
    registers Reg(
        .clock(Clk),
        .reset(Reset),
        .rd_reg_1(Instruction[25:21]),
        .rd_reg_2(Instruction[20:16]),
        .wr_reg(WriteReg),
        .rd_data_1(RegData1),
        .rd_data_2(RegData2),
        .wr_data(WriteData),
        .wr_en(RegWriteEn)
    );
    
    wire [31:0] AfterSignExt;
    sign_extend SignExt(
        .data_16(Instruction[15:0]),
        .data_32(AfterSignExt)
    );
    
    wire [31:0] AfterZeroExt;
    zero_extend ZeroExt(
        .data_16(Instruction[15:0]),
        .data_32(AfterZeroExt)
    );
    
    wire [31:0] ALUOperand2;
    wire [31:0] ALUResult;
    wire Zero;
    assign ALUOperand2 = ALUSrc ?
           AfterSignExt :
           RegData2;
    alu ALU(
        .reg_1(RegData1),
        .reg_2(ALUOperand2),
        .alu_ctr(ALUCtrOut),
        .alu_result(ALUResult),
        .zero(Zero)
    );
    
    wire [31:0] RdDataMem;
    data_memory DataMem(
        .clock(Clk),
        .addr(ALUResult),
        .mem_wr(MemWrite),
        .wr_data(RegData2),
        .mem_rd(MemRead),
        .rd_data(RdDataMem)
    );
    
    reg [31:0] PC;
    wire [31:0] NewPC;
    pc_control_unit PCCtr(
        .old_pc(PC),
        .jump(Jump),
        .branch(Branch),
        .reset(Reset),
        .zero(Zero),
        .j_targ(Instruction[25:0]),
        .beq_offset(AfterSignExt),
        .new_pc(NewPC)
    );
    always @ (posedge Clk) PC <= NewPC;
    
    instruction_memory InstrMem(
        .reset(Reset),
        .addr(PC),
        .instr(Instruction)
    );
    assign WriteData = MemToReg ? RdDataMem : ALUResult;
endmodule
