`timescale 1ns / 1ps

module data_memory(
    input reset,
    input clock,
    input [31:0] addr,
    input mem_wr,
    input [31:0] wr_data,
    input mem_rd,
    
    input [3:0] operand_1,
    input [3:0] operand_2,
    output [3:0] display_1,
    output [3:0] display_2,
    output [7:0] result,
    
    output [31:0] rd_data
    );
    
    reg [31:0] mem_cont [63:0];
    
    assign rd_data = mem_rd && !mem_wr ? mem_cont[addr>>2] : 0;
    
    assign display_1 = mem_cont[0][3:0];
    assign display_2 = mem_cont[1][3:0];
    assign result = mem_cont[2][7:0];
    
    always @ (negedge clock) begin
        if (reset) begin
            mem_cont[0] <= operand_1;
            mem_cont[1] <= operand_2;
            mem_cont[2] <= 0;
        end
        else if (mem_wr) mem_cont[addr>>2] = wr_data;
    end
endmodule
