`timescale 1ns / 1ps

module Top(
    input clk_p,
    input clk_n,
    input [3:0] op1,
    input [3:0] op2,
    input _reset,
    
    output led_clk,
    output led_do,
    output led_en,
    
    output wire seg_clk,
    output wire seg_en,
    output wire seg_do
    );
    wire Reset;
    assign Reset = !_reset;
    
    wire clk_i;
    IBUFGDS IBUFGDS_inst (
        .O(clk_i),
        .I(clk_p),
        .IB(clk_n)
    );
    reg [1:0] div;
    always @ (posedge clk_i) div <= div + 1;
    wire Clk;
    assign Clk = div[1];
    
    wire [3:0] Op1;
    wire [3:0] Op2;
    wire [7:0] Sum;
    
    display DISPLAY (
        .clk(Clk),
        .rst(1'b0),
        .en(8'b01010011),
        .data({4'b0, Op1, 4'b0, Op2, 8'b0, Sum}),
        .dot(8'b0),
        .led(~{Op1, Op2, Sum}),
        .led_clk(led_clk),
        .led_en(led_en),
        .led_do(led_do),
        .seg_clk(seg_clk),
        .seg_en(seg_en),
        .seg_do(seg_do)
    );
    
    wire [31:0] Instruction;
    
    wire RegDst;
    wire Jump;
    wire Branch;
    wire MemRead;
    wire MemWrite;
    wire [2:0] ALU_Op;
    wire MemToReg;
    wire ALUSrc;
    wire RegWriteEn;
    wire SignExtend;
    wire JumpLoad;
    control_unit Ctr(
        .op_code(Instruction[31:26]),
        .reg_dst(RegDst),
        .alu_src(ALUSrc),
        .mem_to_reg(MemToReg),
        .reg_write(RegWriteEn),
        .mem_read(MemRead),
        .mem_write(MemWrite),
        .branch(Branch),
        .alu_op(ALU_Op),
        .jump(Jump),
        .jump_load(JumpLoad)
    );
    
    wire [3:0] ALUCtrOut;
    alu_control_unit ALU_Ctr(
        .funct(Instruction[5:0]),
        .alu_op(ALU_Op),
        .alu_ctr_out(ALUCtrOut)
    );
    
    wire [4:0] WriteReg;
    assign WriteReg = JumpLoad ? 5'b11111 : 
                       (RegDst ? Instruction[15:11] : 
                                 Instruction[20:16]);
    wire [31:0] RegData1;
    wire [31:0] RegData2;
    wire [31:0] WriteData;
    registers Reg(
        .clock(Clk),
        .reset(Reset),
        .rd_reg_1(Instruction[25:21]),
        .rd_reg_2(Instruction[20:16]),
        .wr_reg(WriteReg),
        .rd_data_1(RegData1),
        .rd_data_2(RegData2),
        .wr_data(WriteData),
        .wr_en(RegWriteEn)
    );
    
    wire [31:0] AfterSignExt;
    sign_extend SignExt(
        .data_16(Instruction[15:0]),
        .data_32(AfterSignExt)
    );
    
    wire [31:0] AfterZeroExt;
    zero_extend ZeroExt(
        .data_16(Instruction[15:0]),
        .data_32(AfterZeroExt)
    );
    
    wire [31:0] ALUOperand2;
    wire [31:0] ALUResult;
    wire Zero;
    assign ALUOperand2 = ALUSrc ? (SignExtend ? AfterSignExt : AfterZeroExt) : RegData2;
    alu ALU(
        .reg_1(RegData1),
        .reg_2(ALUOperand2),
        .shamt(Instruction[10:6]),
        .alu_ctr(ALUCtrOut),
        .alu_result(ALUResult),
        .zero(Zero)
    );
    
    wire [31:0] RdDataMem;
    data_memory DataMem(
        .reset(Reset),
        .clock(Clk),
        .addr(ALUResult),
        .mem_wr(MemWrite),
        .wr_data(RegData2),
        .mem_rd(MemRead),
        
        .operand_1(op1),
        .operand_2(op2),
        .display_1(Op1),
        .display_2(Op2),
        .result(Sum),
        
        .rd_data(RdDataMem)
    );
    
    reg [31:0] PC;
    wire [31:0] NewPC;
    wire JumpReg;
    pc_control_unit PCCtr(
        .old_pc(PC),
        .jr_reg(RegData1),
        .jump(Jump),
        .jump_reg(JumpReg),
        .branch(Branch),
        .zero(Zero),
        .j_targ(Instruction[25:0]),
        .beq_offset(AfterSignExt),
        .new_pc(NewPC)
    );
    
    always @ (posedge Clk) begin
        if (Reset) PC <= 0;
        else PC <= NewPC;
    end
    assign JumpReg = Instruction[5:0] == 001000 ? 1 : 0;
    
    instruction_memory InstrMem(
        .clock(Clk),
        .reset(Reset),
        .addr(PC),
        .instr(Instruction)
    );
    assign WriteData = JumpLoad ? PC :
                      (MemToReg ? RdDataMem :
                                  ALUResult);
endmodule
