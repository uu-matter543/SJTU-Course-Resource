`timescale 1ns / 1ps

module instruction_memory(
    input clock,
    input reset,
    input [31:0] addr,
    output [31:0] instr
    );
    
    reg [31:0] mem_cont [63:0];
    
    assign instr = reset ? mem_cont[0] : mem_cont[addr>>2];
    
    initial begin
        mem_cont[0] = 32'b10001100000000010000000000000000;
        mem_cont[1] = 32'b10001100000000100000000000000100;
        mem_cont[2] = 32'b00000000000000100010000001000010;
        mem_cont[3] = 32'b00000000000001000010100001000000;
        mem_cont[4] = 32'b00010000010001010000000000000001;
        mem_cont[5] = 32'b00000001000000010100000000100000;
        mem_cont[6] = 32'b00000000000000100001000001000010;
        mem_cont[7] = 32'b00000000000000010000100001000000;
        mem_cont[8] = 32'b00010000010000000000000000000001;
        mem_cont[9] = 32'b00001000000000000000000000000010;
        mem_cont[10] = 32'b10101100000010000000000000001000;
        mem_cont[11] = 32'b00001000000000000000000000001011;
    end
    
endmodule
