`timescale 1ns / 1ps

module instr_16_tb(
    
    );
    reg sys_clk;
    reg reset;
    
    Top CPU(
        .Clk(sys_clk),
        .Reset(reset)
    );
    
    always #(100) sys_clk = !sys_clk;
    initial begin
        CPU.PC = 0;
        sys_clk = 0;
        reset = 0;
        $readmemh ("lab06dat_tb", CPU.Data_mem.mem_cont);
        $readmemb ("lab06instr_tb", CPU.Instr_mem.mem_cont);
        #100; reset = 1;
        #100; reset = 0;
        
    end
endmodule
