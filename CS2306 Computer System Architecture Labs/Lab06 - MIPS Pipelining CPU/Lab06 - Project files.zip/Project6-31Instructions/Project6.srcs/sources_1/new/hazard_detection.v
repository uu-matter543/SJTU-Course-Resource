module hazard_detection_unit(
    input [4:0] id_rs,
    input [4:0] id_rt,
    input [4:0] ex_rt,
    input ex_mem_read,
    input id_alu_src,
    output reg stall
);
    always @(*) begin
        if (ex_mem_read && ((ex_rt == id_rs) || (ex_rt == id_rt && !id_alu_src)))
            stall = 1'b1;
        else
            stall = 1'b0;
    end
endmodule