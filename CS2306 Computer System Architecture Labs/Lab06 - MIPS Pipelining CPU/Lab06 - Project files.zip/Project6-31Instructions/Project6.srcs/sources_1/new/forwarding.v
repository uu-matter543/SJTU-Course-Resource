`timescale 1ns / 1ps

module forwarding(
    input [4:0] id_rs,
    input [4:0] id_rt,
    input id_alu_src,
    input [4:0] ex_rs,
    input [4:0] ex_rt,
    input [4:0] ex_reg_dst,
    input ex_reg_write,
    input [4:0] mem_reg_dst,
    input mem_reg_write,
    input [4:0] wb_reg_dst,
    input wb_reg_write,
    output reg [1:0] forwardA,
    output reg [1:0] forwardB,
    output reg [1:0] forward_id_rs,
    output reg [1:0] forward_id_rt
);

always @(*) begin
    // Ĭ�ϲ�ǰ��
    forwardA = 2'b00;
    forwardB = 2'b00;
    
    // EX hazard - ǰ��MEM�׶εĽ��
    if (mem_reg_write && (mem_reg_dst != 0) && (mem_reg_dst == ex_rs)) begin
        forwardA = 2'b10;
    end
    if (mem_reg_write && (mem_reg_dst != 0) && (mem_reg_dst == ex_rt)) begin
        forwardB = 2'b10;
    end
    
    // MEM hazard - ǰ��WB�׶εĽ��
    if (wb_reg_write && (wb_reg_dst != 0) && 
       !(mem_reg_write && (mem_reg_dst != 0) && (mem_reg_dst == ex_rs)) && 
       (wb_reg_dst == ex_rs)) begin
        forwardA = 2'b01;
    end
    if (wb_reg_write && (wb_reg_dst != 0) && 
       !(mem_reg_write && (mem_reg_dst != 0) && (mem_reg_dst == ex_rt)) && 
       (wb_reg_dst == ex_rt)) begin
        forwardB = 2'b01;
    end
    // ID�׶ε�ǰ���߼���������
    forward_id_rs = 2'b00;
    if (id_rs != 0) begin
        if (ex_reg_write && (ex_reg_dst == id_rs))
            forward_id_rs = 2'b11;  // ǰ��EX�׶ν��
        else if (mem_reg_write && (mem_reg_dst == id_rs))
            forward_id_rs = 2'b10;  // ǰ��MEM�׶ν��
        else if (wb_reg_write && (wb_reg_dst == id_rs))
            forward_id_rs = 2'b01;  // ǰ��WB�׶ν��
    end

    forward_id_rt = 2'b00;
    if (id_rt != 0) begin
        if (ex_reg_write && (ex_reg_dst == id_rt) && !id_alu_src)
            forward_id_rt = 2'b11;  // ǰ��EX�׶ν��
        else if (mem_reg_write && (mem_reg_dst == id_rt) && !id_alu_src)
            forward_id_rt = 2'b10;  // ǰ��MEM�׶ν��
        else if (wb_reg_write && (wb_reg_dst == id_rt) && !id_alu_src)
            forward_id_rt = 2'b01;  // ǰ��WB�׶ν��
    end
end

endmodule
