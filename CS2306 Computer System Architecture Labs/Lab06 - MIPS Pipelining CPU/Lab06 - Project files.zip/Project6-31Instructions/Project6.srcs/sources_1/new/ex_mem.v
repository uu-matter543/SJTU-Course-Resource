`timescale 1ns / 1ps

module ex_mem(
    input clock,
    
    input ex_mem_to_reg,
    output reg mem_mem_to_reg,
    input ex_reg_write,
    output reg mem_reg_write,
    input ex_mem_read,
    output reg mem_mem_read,
    input ex_mem_write,
    output reg mem_mem_write,
    input [4:0] ex_reg_dst,
    output reg [4:0] mem_reg_dst,
    
    input [31:0] ex_cont,
    output reg [31:0] mem_cont,
    input [31:0] alu_rst,
    output reg [31:0] alu_output
    );
    reg mem_to_reg_buffer;
    reg reg_write_buffer;
    reg mem_read_buffer;
    reg mem_write_buffer;
    reg [31:0] cont_buffer;
    reg [31:0] alu_buffer;
    reg [4:0] reg_dst_buffer;
    always @ (negedge clock) begin
        mem_to_reg_buffer <= ex_mem_to_reg;
        reg_write_buffer <= ex_reg_write;
        mem_read_buffer <= ex_mem_read;
        mem_write_buffer <= ex_mem_write;
        reg_dst_buffer <= ex_reg_dst;
        cont_buffer <= ex_cont;
        alu_buffer <= alu_rst;
    end
    always @ (posedge clock) begin
        mem_mem_to_reg <= mem_to_reg_buffer;
        mem_reg_write <= reg_write_buffer;
        mem_mem_read <= mem_read_buffer;
        mem_mem_write <= mem_write_buffer;
        mem_reg_dst <= reg_dst_buffer;
        mem_cont <= cont_buffer;
        alu_output <= alu_buffer;
    end
endmodule
