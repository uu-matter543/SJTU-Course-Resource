`timescale 1ns / 1ps

module sign_extend(
    input [15:0] data_16,
    output [31:0] data_32
    );
    
    assign data_32 = {{16{data_16[15]}}, data_16};
endmodule
