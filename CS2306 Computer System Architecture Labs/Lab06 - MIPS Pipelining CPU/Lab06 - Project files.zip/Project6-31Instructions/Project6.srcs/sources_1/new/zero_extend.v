`timescale 1ns / 1ps

module zero_extend(
    input [15:0] data_16,
    output [31:0] data_32
    );
    
    assign data_32 = {{16{1'b0}}, data_16};
endmodule
