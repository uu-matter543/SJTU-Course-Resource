`timescale 1ns / 1ps

module control_unit(
    input [5:0] op_code,
    input [5:0] funct,
    output reg reg_dst,
    output reg alu_src,
    output reg mem_to_reg,
    output reg reg_write,
    output reg mem_read,
    output reg mem_write,
    output reg branch,
    output reg [2:0] alu_op,
    output reg jump,
    output reg jr,
    output reg sign_ext,
    output reg jump_load
    );
    initial begin
        reg_dst = 0;
        alu_src = 0;
        mem_to_reg = 0;
        reg_write = 0;
        mem_read = 0;
        mem_write = 0;
        branch = 0;
        alu_op = 3'b000;
        jump = 0;
        jr = 0;
        sign_ext = 0;
        jump_load = 0;
    end
    always @(op_code or funct) begin
        casex (op_code)
        6'b000000: begin // R
            reg_dst = 1;
            alu_src = 0;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b111;
            jump = 0;
            jr = (funct == 6'b001000) ? 1 : 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b100011: begin // lw
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 1;
            reg_write = 1;
            mem_read = 1;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b000;
            jump = 0;
            jr = 0;
            sign_ext = 1;
            jump_load = 0;
        end
        6'b101011: begin // sw
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 0;
            mem_read = 0;
            mem_write = 1;
            branch = 0;
            alu_op = 3'b000;
            jump = 0;
            jr = 0;
            sign_ext = 1;
            jump_load = 0;
        end
        6'b00100x: begin // addi,addiu
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b000;
            jump = 0;
            jr = 0;
            if (op_code[0] == 0) sign_ext = 1;
            else sign_ext = 0;
            jump_load = 0;
        end
        6'b001100: begin //andi
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b010;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b001101: begin // ori
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b011;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b001110: begin // xori
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b100;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b001111: begin //lui
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b001;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b001010: begin //slti
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b101;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b001010: begin //sltiu
            reg_dst = 0;
            alu_src = 1;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b110;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b000010: begin // j
            reg_dst = 0;
            alu_src = 0;
            mem_to_reg = 0;
            reg_write = 0;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b000;
            jump = 1;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        6'b000011: begin // jal
            reg_dst = 0;
            alu_src = 0;
            mem_to_reg = 0;
            reg_write = 1;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b000;
            jump = 1;
            jr = 0;
            sign_ext = 0;
            jump_load = 1;
        end
        default: begin
            reg_dst = 0;
            alu_src = 0;
            mem_to_reg = 0;
            reg_write = 0;
            mem_read = 0;
            mem_write = 0;
            branch = 0;
            alu_op = 3'b000;
            jump = 0;
            jr = 0;
            sign_ext = 0;
            jump_load = 0;
        end
        endcase
    end

endmodule
