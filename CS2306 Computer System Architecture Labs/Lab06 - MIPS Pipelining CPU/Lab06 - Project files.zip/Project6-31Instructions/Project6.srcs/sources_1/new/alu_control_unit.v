`timescale 1ns / 1ps

module alu_control_unit(
    input [5:0] funct,
    input [2:0] alu_op,
    output reg [3:0] alu_ctr_out
    );
    
    always @(alu_op or funct) begin
        casex ({alu_op, funct})
        //I-type
        9'b000xxxxxx: alu_ctr_out <= 4'b0010; //add
        9'b001xxxxxx: alu_ctr_out <= 4'b0011; //lui
        9'b010xxxxxx: alu_ctr_out <= 4'b0000; //and
        9'b011xxxxxx: alu_ctr_out <= 4'b0001; //or
        9'b100xxxxxx: alu_ctr_out <= 4'b1101; //xor
        9'b101xxxxxx: alu_ctr_out <= 4'b0111; //slt
        9'b110xxxxxx: alu_ctr_out <= 4'b0101; //sltu
        //R-type
        9'b11110000x: alu_ctr_out <= 4'b0010; //add,addu
        9'b11110001x: alu_ctr_out <= 4'b0110; //sub,subu
        9'b111100100: alu_ctr_out <= 4'b0000; //and
        9'b111100101: alu_ctr_out <= 4'b0001; //or
        9'b111100110: alu_ctr_out <= 4'b1101; //xor
        9'b111100111: alu_ctr_out <= 4'b1100; //nor
        9'b111101010: alu_ctr_out <= 4'b0111; //slt
        9'b111101011: alu_ctr_out <= 4'b0101; //sltu
        9'b111000000: alu_ctr_out <= 4'b1110; //sll
        9'b111000010: alu_ctr_out <= 4'b1111; //srl
        9'b111000011: alu_ctr_out <= 4'b1010; //sra
        9'b111000100: alu_ctr_out <= 4'b1001; //sllv
        9'b111000110: alu_ctr_out <= 4'b1011; //srlv
        9'b111000111: alu_ctr_out <= 4'b1000; //srav
        9'b111001000: alu_ctr_out <= 4'b0100; //jr
        default: alu_ctr_out <= 4'b0;
        endcase
    end
endmodule
