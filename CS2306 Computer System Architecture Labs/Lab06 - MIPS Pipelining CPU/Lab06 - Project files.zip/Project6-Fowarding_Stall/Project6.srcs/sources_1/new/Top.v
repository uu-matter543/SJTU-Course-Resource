`timescale 1ns / 1ps

module Top(
    input Reset,
    input Clk
    );
    reg [31:0] PC;
    wire [31:0] IF_instr;
    instruction_memory Instr_mem(
        .clock(Clk),
        .reset(Reset),
        .addr(PC),
        .instr(IF_instr)
    );
    
    wire Stall;
    wire [31:0] ID_instr;
    wire [31:0] ID_pc;
    wire [31:0] PC_add_4;
    assign PC_add_4 = PC + 4;
    if_id IF_ID(
        .clock(Clk),
        .stall(Stall),
        .if_instr(IF_instr),
        .id_instr(ID_instr),
        .if_pc(PC_add_4),
        .id_pc(ID_pc)
    );
    
    wire ID_reg_dst;
    wire ID_alu_src;
    wire ID_mem_to_reg;
    wire ID_reg_write;
    wire ID_mem_read;
    wire ID_mem_write;
    wire ID_branch;
    wire [2:0] ID_alu_op;
    wire ID_jump;
    wire ID_sign_ext;
    wire ID_jump_load;
    control_unit Ctr(
        .op_code(ID_instr[31:26]),
        .reg_dst(ID_reg_dst),
        .alu_src(ID_alu_src),
        .mem_to_reg(ID_mem_to_reg),
        .reg_write(ID_reg_write),
        .mem_read(ID_mem_read),
        .mem_write(ID_mem_write),
        .branch(ID_branch),
        .alu_op(ID_alu_op),
        .jump(ID_jump),
        .sign_ext(ID_sign_ext),
        .jump_load(ID_jump_load)
    );
    
    wire [31:0] ID_reg_data_1;
    wire [31:0] ID_reg_data_2;
    wire [4:0] WB_reg_dst;
    wire [31:0] WB_data;
    wire WB_reg_write;
    registers Reg(
        .clock(Clk),
        .reset(Reset),
        .rd_reg_1(ID_instr[25:21]),
        .rd_reg_2(ID_instr[20:16]),
        .wr_reg(WB_reg_dst),
        .rd_data_1(ID_reg_data_1),
        .rd_data_2(ID_reg_data_2),
        .wr_data(WB_data),
        .wr_en(WB_reg_write)
    );
    
    wire [31:0] ID_signext;
    sign_extend SignExt(
        .data_16(ID_instr[15:0]),
        .data_32(ID_signext)
    );
    wire [31:0] ID_zeroext;
    zero_extend ZeroExt(
        .data_16(ID_instr[15:0]),
        .data_32(ID_zeroext)
    );
    
    wire EX_alu_src;
    wire EX_mem_to_reg;
    wire EX_reg_write;
    wire EX_mem_read;
    wire EX_mem_write;
    wire EX_branch;
    wire [2:0] EX_alu_op;
    wire [10:0] EX_shamt_funct;
    wire EX_jump_load;
    wire [31:0] EX_pc;
    wire [31:0] EX_alu_src_1;
    wire [31:0] EX_alu_src_2;
    wire [31:0] EX_ext;
    wire [4:0] EX_reg_dst;
    wire [4:0] EX_rs;
    wire [4:0] EX_rt;
    id_ex ID_EX(
        .clock(Clk),
        .id_sign_ext(ID_sign_ext),
        .id_reg_dst(ID_reg_dst),
        .id_alu_src(ID_alu_src),
        .ex_alu_src(EX_alu_src),
        .id_mem_to_reg(ID_mem_to_reg),
        .ex_mem_to_reg(EX_mem_to_reg),
        .id_reg_write(ID_reg_write),
        .ex_reg_write(EX_reg_write),
        .id_mem_read(ID_mem_read),
        .ex_mem_read(EX_mem_read),
        .id_mem_write(ID_mem_write),
        .ex_mem_write(EX_mem_write),
        .id_branch(ID_branch),
        .ex_branch(EX_branch),
        .id_alu_op(ID_alu_op),
        .ex_alu_op(EX_alu_op),
        .id_shamt_funct(ID_instr[10:0]),
        .ex_shamt_funct(EX_shamt_funct),
        .id_jump_load(ID_jump_load),
        .ex_jump_load(EX_jump_load),
        .id_pc(ID_pc),
        .ex_pc(EX_pc),
        .reg_data_1(ID_reg_data_1),
        .alu_src_1(EX_alu_src_1),
        .reg_data_2(ID_reg_data_2),
        .alu_src_2(EX_alu_src_2),
        .after_sign_ext(ID_signext),
        .after_zero_ext(ID_zeroext),
        .after_ext(EX_ext),
        .reg_dst_opt(ID_instr[20:11]),
        .reg_dst(EX_reg_dst),
        .id_rs(ID_instr[25:21]),
        .id_rt(ID_instr[20:16]),
        .ex_rs(EX_rs),
        .ex_rt(EX_rt),
        .stall(Stall)
    );
    
    wire [3:0] EX_alu_ctr;
    alu_control_unit ALU_ctr(
        .funct(EX_shamt_funct[5:0]),
        .alu_op(EX_alu_op),
        .alu_ctr_out(EX_alu_ctr)
    );
    
    wire [1:0] forwardA, forwardB;
    wire MEM_reg_write;
    wire [4:0] MEM_reg_dst;
    forwarding FU(
        .ex_rs(EX_rs),
        .ex_rt(EX_rt),
        .mem_reg_dst(MEM_reg_dst),
        .mem_reg_write(MEM_reg_write),
        .wb_reg_dst(WB_reg_dst),
        .wb_reg_write(WB_reg_write),
        .forwardA(forwardA),
        .forwardB(forwardB)
    );
    
    hazard_detection_unit HDU(
        .id_rs(ID_instr[25:21]),
        .id_rt(ID_instr[20:16]),
        .ex_rt(EX_rt),
        .ex_mem_read(EX_mem_read),
        .stall(Stall)
    );
    
    wire [31:0] EX_alu_input1, EX_alu_input2;
    wire [31:0] EX_alu_src_opt;
    wire [31:0] MEM_alu_output;
    assign EX_alu_src_opt = EX_alu_src ? EX_ext : EX_alu_src_2;
    assign EX_alu_input1 = (forwardA == 2'b10) ? MEM_alu_output : 
                           (forwardA == 2'b01) ? WB_data : 
                                                 EX_alu_src_1;
    assign EX_alu_input2 = (forwardB == 2'b10) ? MEM_alu_output : 
                           (forwardB == 2'b01) ? WB_data : 
                                                 EX_alu_src_opt;
    wire [31:0] EX_alu_result;
    wire EX_zero;
    alu ALU(
        .reg_1(EX_alu_input1),
        .reg_2(EX_alu_input2),
        .shamt(EX_shamt_funct[10:6]),
        .alu_ctr(EX_alu_ctr),
        .alu_result(EX_alu_result),
        .zero(EX_zero)
    );
    
    always @ (posedge Clk) begin
        if (Reset) 
            PC <= 0;
        else if (Stall) 
            PC <= PC;
        else if (ID_jump) 
            PC <= {ID_pc[31:28], ID_instr[25:0] << 2};
        else if (EX_branch && EX_zero) 
            PC <= (EX_alu_src_2 << 2) + EX_pc;
        else 
            PC <= PC_add_4;
    end
    
    wire MEM_mem_to_reg;
    wire MEM_mem_read;
    wire MEM_mem_write;
    wire [31:0] result;
    wire [31:0] MEM_cont;
    assign result = EX_jump_load ? EX_pc : EX_alu_result;
    ex_mem EX_MEM(
        .clock(Clk),
        .ex_mem_to_reg(EX_mem_to_reg),
        .mem_mem_to_reg(MEM_mem_to_reg),
        .ex_reg_write(EX_reg_write),
        .mem_reg_write(MEM_reg_write),
        .ex_mem_read(EX_mem_read),
        .mem_mem_read(MEM_mem_read),
        .ex_mem_write(EX_mem_write),
        .mem_mem_write(MEM_mem_write),
        .ex_reg_dst(EX_reg_dst),
        .mem_reg_dst(MEM_reg_dst),
        
        .ex_cont(EX_alu_src_2),
        .mem_cont(MEM_cont),
        .alu_rst(result),
        .alu_output(MEM_alu_output)
    );
    
    wire [31:0] MEM_rd_data;
    data_memory Data_mem(
        .clock(Clk),
        .addr(MEM_alu_output),
        .mem_wr(MEM_mem_write),
        .wr_data(MEM_cont),
        .mem_rd(MEM_mem_read),
        .rd_data(MEM_rd_data)
    );
    
    mem_wb MEM_WB(
        .clock(Clk),
        .mem_reg_write(MEM_reg_write),
        .wb_reg_write(WB_reg_write),
        .mem_reg_dst(MEM_reg_dst),
        .wb_reg_dst(WB_reg_dst),
        .mem_mem_to_reg(MEM_mem_to_reg),
        .alu_output(MEM_alu_output),
        .mem_data(MEM_rd_data),
        .wb_data(WB_data)
    );
endmodule
