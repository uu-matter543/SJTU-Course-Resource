`timescale 1ns / 1ps

module mem_wb(
    input clock,
    
    input mem_reg_write,
    output wb_reg_write,
    input [4:0] mem_reg_dst,
    output [4:0] wb_reg_dst,
    
    input mem_mem_to_reg,
    input [31:0] alu_output,
    input [31:0] mem_data,
    output [31:0] wb_data
    );
    reg reg_write_buffer;
    reg [4:0] reg_dst_buffer;
    reg mem_to_reg_buffer;
    reg [31:0] alu_buffer;
    reg [31:0] mem_buffer;
    always @ (negedge clock) begin
        reg_write_buffer = mem_reg_write;
        reg_dst_buffer = mem_reg_dst;
        mem_to_reg_buffer = mem_mem_to_reg;
        alu_buffer = alu_output;
        mem_buffer = mem_data;
    end
    assign wb_reg_write = reg_write_buffer;
    assign wb_reg_dst = reg_dst_buffer;
    assign wb_data = mem_mem_to_reg ? mem_buffer : alu_buffer;
endmodule
