`timescale 1ns / 1ps

module id_ex(
    input clock,
    
    input id_sign_ext,
    input id_reg_dst,
    
    input id_alu_src,
    output reg ex_alu_src,
    input id_mem_to_reg,
    output reg ex_mem_to_reg,
    input id_reg_write,
    output reg ex_reg_write,
    input id_mem_read,
    output reg ex_mem_read,
    input id_mem_write,
    output reg ex_mem_write,
    input id_branch,
    output reg ex_branch,
    input [2:0] id_alu_op,
    output reg [2:0] ex_alu_op,
    input [10:0] id_shamt_funct,
    output reg [10:0] ex_shamt_funct,
    input id_jump_load,
    output reg ex_jump_load,
    input [31:0] id_pc,
    output reg [31:0] ex_pc,
    
    input [31:0] reg_data_1,
    output reg [31:0] alu_src_1,
    input [31:0] reg_data_2,
    output reg [31:0] alu_src_2,
    input [31:0] after_sign_ext,
    input [31:0] after_zero_ext,
    output reg [31:0] after_ext,
    input [9:0] reg_dst_opt,
    output reg [4:0] reg_dst
    );
    reg alu_src_buffer;
    reg mem_to_reg_buffer;
    reg reg_write_buffer;
    reg mem_read_buffer;
    reg mem_write_buffer;
    reg branch_buffer;
    reg [2:0] alu_op_buffer;
    reg [10:0] shamt_funct_buffer;
    reg jump_load_buffer;
    reg [31:0] pc_buffer;
    
    reg [31:0] reg_data_1_buffer;
    reg [31:0] reg_data_2_buffer;
    reg [31:0] signext_buffer;
    reg [31:0] zeroext_buffer;
    reg [9:0] reg_dst_index_buffer;
    initial begin
        alu_src_buffer = 0;
        mem_to_reg_buffer = 0;
        reg_write_buffer = 0;
        mem_read_buffer = 0;
        mem_write_buffer = 0;
        branch_buffer = 0;
        alu_op_buffer = 0;
        shamt_funct_buffer = 0;
        jump_load_buffer = 0;
        pc_buffer = 0;
        ex_alu_src = 0;
        ex_mem_to_reg = 0;
        ex_reg_write = 0;
        ex_mem_read = 0;
        ex_mem_write = 0;
        ex_branch = 0;
        ex_alu_op = 0;
        ex_shamt_funct = 0;
        ex_jump_load = 0;
        ex_pc = 0;
    end
    always @ (negedge clock) begin
        alu_src_buffer <= id_alu_src;
        mem_to_reg_buffer <= id_mem_to_reg;
        reg_write_buffer <= id_reg_write;
        mem_read_buffer <= id_mem_read;
        mem_write_buffer <= id_mem_write;
        branch_buffer <= id_branch;
        alu_op_buffer <= id_alu_op;
        shamt_funct_buffer <= id_shamt_funct;
        jump_load_buffer <= id_jump_load;
        pc_buffer <= id_pc;
        
        reg_data_1_buffer <= reg_data_1;
        reg_data_2_buffer <= reg_data_2;
        signext_buffer <= after_sign_ext;
        zeroext_buffer <= after_zero_ext;
        reg_dst_index_buffer <= reg_dst_opt;
    end
    always @ (posedge clock) begin
        ex_alu_src <= alu_src_buffer;
        ex_mem_to_reg <= mem_to_reg_buffer;
        ex_reg_write <= reg_write_buffer;
        ex_mem_read <= mem_read_buffer;
        ex_mem_write <= mem_write_buffer;
        ex_branch <= branch_buffer;
        ex_alu_op <= alu_op_buffer;
        ex_shamt_funct <= shamt_funct_buffer;
        ex_jump_load <= jump_load_buffer;
        ex_pc <= pc_buffer;
        
        alu_src_1 <= reg_data_1_buffer;
        alu_src_2 <= reg_data_2_buffer;
        after_ext <= id_sign_ext ? signext_buffer : zeroext_buffer;
        reg_dst <= id_jump_load ? 5'b11111 :
                    (id_reg_dst ? reg_dst_opt[4:0]:
                                  reg_dst_opt[9:5]);
    end
endmodule
