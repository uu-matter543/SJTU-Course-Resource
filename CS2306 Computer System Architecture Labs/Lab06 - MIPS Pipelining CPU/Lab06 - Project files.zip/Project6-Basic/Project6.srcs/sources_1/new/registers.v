`timescale 1ns / 1ps

module registers(
    input clock,
    input reset,
    input [4:0] rd_reg_1,
    input [4:0] rd_reg_2,
    input [4:0] wr_reg,
    output [31:0] rd_data_1,
    output [31:0] rd_data_2,
    input [31:0] wr_data,
    input wr_en
    );
    reg [31:0] reg_cont [31:0];
    integer i;

    assign rd_data_1 = reg_cont[rd_reg_1];
    assign rd_data_2 = reg_cont[rd_reg_2];
    
    always @ (reset) begin
        if (reset) begin
            for (i = 0; i < 32; i = i + 1) reg_cont[i] <= 0;
        end
    end
    
    always @ (negedge clock) 
        if (wr_en) reg_cont[wr_reg] <= wr_data;
endmodule
