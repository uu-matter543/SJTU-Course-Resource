`timescale 1ns / 1ps

module if_id(
    input clock,
    input [31:0] if_instr,
    output reg [31:0] id_instr,
    input [31:0] if_pc,
    output reg [31:0] id_pc
    );
    reg [31:0] instr_buffer;
    reg [31:0] pc_buffer;
    initial begin
        instr_buffer = 0;
        pc_buffer = 0;
        id_pc = 0;
        id_instr = 0;
    end
    always @ (negedge clock) begin
        instr_buffer <= if_instr;
        pc_buffer <= if_pc;
    end
    always @ (posedge clock) begin
        id_pc <= pc_buffer;
        id_instr <= instr_buffer;
    end
endmodule
